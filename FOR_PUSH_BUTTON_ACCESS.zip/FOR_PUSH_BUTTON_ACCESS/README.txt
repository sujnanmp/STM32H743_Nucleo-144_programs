FOR PUSH BUTTON ACCESS 
Push-buttons
B1 USER (blue button): the user button is connected to the I/O PC13 by default (tamper
support: SB51 ON and SB58 OFF) or PA0 (wake-up support: SB58 ON and SB51 OFF) of
the STM32H7 series microcontroller.
B2 RESET (black button): this push-button is connected to NRST and is used to reset the
STM32H7 series microcontroller

PC 13 AS GPIO  INPUT
